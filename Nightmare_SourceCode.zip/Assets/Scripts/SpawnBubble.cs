﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnBubble : MonoBehaviour {

    public Transform bubblePrefab;
    public Transform evilBubblePrefab;

    public Transform wallA;
    public Transform wallB;
    public Transform wallC;
    public Transform wallD;

    public SpeedManager speedManager;
    public float counter = 0;
    public float evilCounter = -20;

    public int spawnRate = 3;

    private void Start()
    {
        SpawnInArea();
    }

    public void SpawnInArea()
    {
        Vector2 spawnPosition = new Vector2 (Random.Range (wallB.position.x -0.5f, wallD.position.x + 0.5f), Random.Range(wallA.position.y - 0.5f, wallC.position.y + 0.5f));
        int zRot = Random.Range(0, 360);

        Instantiate(bubblePrefab, spawnPosition, Quaternion.Euler(0, 0, zRot));        
    }

    public void SpawnEvilInArea()
    {
        Vector2 spawnPosition = new Vector2(Random.Range(wallB.position.x - 0.5f, wallD.position.x + 0.5f), Random.Range(wallA.position.y - 0.5f, wallC.position.y + 0.5f));
        int zRot = Random.Range(0, 360);

        Instantiate(evilBubblePrefab, spawnPosition, Quaternion.Euler(0, 0, zRot));
    }

    private void Update()
    {
        counter = counter + (Time.deltaTime * speedManager.timeSpeed);

        if (counter >= spawnRate)
        {
            counter = 0f;
            SpawnInArea();
        }

        evilCounter = evilCounter + (Time.deltaTime * (speedManager.timeSpeed * 3));

        if (evilCounter >= spawnRate)
        {
            evilCounter = -15f;
            SpawnEvilInArea();
        }
    }

}
