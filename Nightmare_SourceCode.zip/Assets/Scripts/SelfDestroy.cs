﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SelfDestroy : MonoBehaviour {

    public PlayRandomSound playRandomSound;
    public SpawnBubble spawnBubble;
    public WallMovement[] wallMovements;

    public int targetWall;

    private void Awake()
    {
        playRandomSound = GameObject.Find("Sound").GetComponent<PlayRandomSound>();
        spawnBubble = GameObject.Find("Floor").GetComponent<SpawnBubble>();
        targetWall = Random.Range(0, wallMovements.Length);
        wallMovements[0] = GameObject.Find("WallA").GetComponent<WallMovement>();
        wallMovements[1] = GameObject.Find("WallB").GetComponent<WallMovement>();
        wallMovements[2] = GameObject.Find("WallC").GetComponent<WallMovement>();
        wallMovements[3] = GameObject.Find("WallD").GetComponent<WallMovement>();
    }
    
    public void ToDestroy()
    {
        playRandomSound.BubbleExplode();
        spawnBubble.SpawnInArea();
        Destroy(gameObject);
    }

    public void OnlyDestroy()
    {
        Destroy(gameObject);
    }

    void OnTriggerEnter(Collider col)
    {
        if (col.CompareTag("Wall"))
        {
            ToDestroy();
        }
    }

    void OnMouseOver()
    {
        if (gameObject.CompareTag("Bubble"))
        {
            wallMovements[targetWall].ChangeDirection();
            ToDestroy();
        }
        if (gameObject.CompareTag("EvilBubble"))
        {
            wallMovements[targetWall].ApplyForce();
            ToDestroy();
        }
    }
}
