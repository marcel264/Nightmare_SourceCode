﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallBoxCollision : MonoBehaviour {

    public WallMovement wallMovement;

    private void Awake()
    {
        wallMovement = gameObject.transform.parent.GetComponent<WallMovement>();
    }

    void OnMouseOver()
    {
        wallMovement.GameOver();
    }
}
