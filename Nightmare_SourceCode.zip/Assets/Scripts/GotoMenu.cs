﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GotoMenu : MonoBehaviour {

    public UIManager uiManager;

    public void GoMenuNow()
    {
        uiManager.GoToMenu();
    }
}
