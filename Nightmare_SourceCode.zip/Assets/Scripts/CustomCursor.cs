﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomCursor : MonoBehaviour {
    
    public Texture2D[] cursorTexture;
    public GameObject[] cursorTexturePreview;

    public CursorMode cursorMode = CursorMode.Auto;
    public Vector2 hotSpot = Vector2.zero;

    public UIManager uiManager;

    public int numNav = 0;
    
    public void NextCursor()
    {
        cursorTexturePreview[numNav].SetActive(false);
        numNav = numNav + 1;
        if (numNav > cursorTexture.Length -1)
        {
            numNav = 0;
        }
        cursorTexturePreview[numNav].SetActive(true);
    }

    public void PreviousCursor()
    {
        cursorTexturePreview[numNav].SetActive(false);
        numNav = numNav - 1;
        if (numNav < 0)
        {
            numNav = cursorTexture.Length -1;
        }
        cursorTexturePreview[numNav].SetActive(true);
    }

    public void PickSkin()
    {

        {
            Cursor.SetCursor(cursorTexture[numNav], hotSpot, cursorMode);
        }
    }

    public void DefaultCursor()
    {
        Cursor.SetCursor(cursorTexture[0], hotSpot, cursorMode);
    }
}
