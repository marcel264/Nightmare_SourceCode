﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpeedManager : MonoBehaviour {
        
    public Text timeScoreIndex;
    public Text timeSpeedIndex;

    public float timeScore;
    public float timeSpeed = 1;

    private void Awake()
    {
        timeScore = 0f;
        timeSpeed = 1f;
    }

    private void OnEnable()
    {
        timeScore = 0f;
        timeSpeed = 1f;
    }

    public void Update()
    {
        timeSpeed = timeSpeed * 1.0003f;
        timeScore = timeScore + Time.deltaTime;

        timeScoreIndex.text = ("TIME " + timeScore.ToString("F2"));
        timeSpeedIndex.text = ("SPEED x" + timeSpeed.ToString("F1") + " %");
    }
}
