﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallMovement : MonoBehaviour {

    public CustomCursor customCursor;    
    public UIManager uiManager;
    public SpeedManager speedManager;

    public Vector3 direction = Vector3.right;

    public int wallRecoil;
    public Animator animComp;

    private void Awake()
    {
        animComp = gameObject.GetComponent<Animator>();
    }

    public void OnEnable()
    {
        transform.localPosition = Vector3.zero;
    }

    void Update () {
        transform.Translate(direction * (Time.deltaTime * speedManager.timeSpeed) / 10);
        //if (transform.position.x < -1 )
        //{
        //    GameOver();
        //}
    }

    public void GameOver()
    {
        Debug.Log("Game Over");
        uiManager.lastScore = speedManager.timeScore;
        uiManager.ScoreCalculations();
        DestroyAllObjects();
        uiManager.GameOver();
        customCursor.DefaultCursor();

    }

    void OnMouseOver()
    {
        GameOver();
    }   

    public void ChangeDirection()
    {
        animComp.SetBool("changeDir", true);
        transform.Translate(new Vector3(-0.25f, 0f));
    }

    public void ApplyForce()
    {
        animComp.SetBool("applyForce", true);
        transform.Translate(new Vector3(+0.5f * speedManager.timeSpeed, 0f));
    }

    private void AnimTurnFalse()
    {
        animComp.SetBool("changeDir", false);
        animComp.SetBool("applyForce", false);
    }

    void DestroyAllObjects()
    {
        GameObject[] gameObjects = GameObject.FindGameObjectsWithTag("Bubble");

        for (var i = 0; i < gameObjects.Length; i++)
        {
            Destroy(gameObjects[i]);
        }

        GameObject[] evilGameObjects = GameObject.FindGameObjectsWithTag("EvilBubble");

        for (var i = 0; i < evilGameObjects.Length; i++)
        {
            Destroy(evilGameObjects[i]);
        }
    }
}
