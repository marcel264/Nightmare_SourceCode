﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour {

    public PlayRandomSound playRandomSound;
    public CustomCursor customCursor;

    public Texture2D unlockCursorTexture;
    public GameObject unlockTexturePreview;

    public AudioSource soundSource;
    public AudioSource musicSource;

    //public Image skinTexture;    
    //public Image logoImage;
    //public Image hitImage;

    public Image fadeImage;
    public Animation anim;

    public float lastScore = 0f;
    public float highScore = 0f;

    public Text lastScoreIndex;
    public Text highScoreIndex;

    [Space(10)]

    public GameObject[] disableObjectMenu;
    public GameObject[] enableObjectMenu;

    [Space(10)]

    public GameObject[] disableObjectPlay;
    public GameObject[] enableObjectPlay;

    [Space(10)]

    public GameObject[] disableObjectGameOver;
    public GameObject[] enableObjectGameOver;

    [Space(10)]

    public string[] lowTierSent;
    public string[] medTierSent;
    public string[] highTierSent;

    private void Start()
    {
        //GoToMenu();
    }

    public void GoToMenu()
    {
        if (!musicSource.isPlaying)
        {
            musicSource.Play();
        }
        StartCoroutine(FadeMainMenu());
    }

    public void PlayGame()
    {
        customCursor.PickSkin();
        StartCoroutine(FadePlay());
    }

    public void GameOver()
    {
        StartCoroutine(FadeGameOver());
    }

    public void QuitGame()
    {
        Debug.Log("Goodbye");
        Application.Quit();
    }

    IEnumerator FadePlay()
    {
        Debug.Log("playing anim");
        anim.Play();                                             //Pasamos a true la animacion de fade
        yield return new WaitUntil(() => fadeImage.color.a == 1);                   //Tiempo de espera antes de leer la siguiente linea (para que termine el fade)
        for (int i = 0; i < disableObjectPlay.Length; i++)
        {
            disableObjectPlay[i].SetActive(false);
        }
        for (int i = 0; i < enableObjectPlay.Length; i++)
        {
            enableObjectPlay[i].SetActive(true);
        }
    }

    IEnumerator FadeGameOver()
    {
        Debug.Log("playing anim");
        anim.Play();                                             //Pasamos a true la animacion de fade
        yield return new WaitUntil(() => fadeImage.color.a == 1);                   //Tiempo de espera antes de leer la siguiente linea (para que termine el fade)
        for (int i = 0; i < disableObjectGameOver.Length; i++)
        {
            disableObjectGameOver[i].SetActive(false);
        }
        for (int i = 0; i < enableObjectGameOver.Length; i++)
        {
            enableObjectGameOver[i].SetActive(true);
        }
    }

    IEnumerator FadeMainMenu()
    {
        Debug.Log("playing anim");
        anim.Play();                                             //Pasamos a true la animacion de fade
        yield return new WaitUntil(() => fadeImage.color.a == 1);                   //Tiempo de espera antes de leer la siguiente linea (para que termine el fade)
        for (int i = 0; i < disableObjectMenu.Length; i++)
        {
            disableObjectMenu[i].SetActive(false);
        }
        for (int i = 0; i < enableObjectMenu.Length; i++)
        {
            enableObjectMenu[i].SetActive(true);
        }
    }

    public void ScoreCalculations()
    {
        if (lastScore > highScore)
        {
            highScore = lastScore;
            highScoreIndex.text = ("YOUR HIGHEST SCORE IS " + highScore.ToString("F0") + " SECONDS, \n CONGRATS! THATS A NEW HIGH SCORE");
        }
        else
        {
            highScoreIndex.text = ("YOUR HIGHEST SCORE IS " + highScore.ToString("F0") + " SECONDS");
        }

        if (lastScore <= 40f)
        {
            int randNum = Random.Range(0, lowTierSent.Length);
            lastScoreIndex.text = ("YOU LASTED " + lastScore.ToString("F0") + " SECONDS" + "\n" + lowTierSent[randNum]);
            return;
        }

        if (lastScore < 80f)
        {
            int randNum = Random.Range(0, medTierSent.Length);
            lastScoreIndex.text = ("YOU LASTED " + lastScore.ToString("F0") + " SECONDS" + "\n" + medTierSent[randNum]);
        }

        if (lastScore >= 80f)
        {
            customCursor.cursorTexture[5] = unlockCursorTexture;
            customCursor.cursorTexturePreview[5] = unlockTexturePreview;
            int randNum = Random.Range(0, highTierSent.Length);
            lastScoreIndex.text = ("YOU LASTED " + lastScore.ToString("F0") + " SECONDS" + "\n" + highTierSent[randNum]);
        }
    }

    public void ButtonSound()
    {
        playRandomSound.ButtonClick();
    }

    public void MuteSound()
    {
        soundSource.mute = !soundSource.mute;
    }

    public void MuteMusic()
    {
        musicSource.mute = !musicSource.mute;
    }
}
