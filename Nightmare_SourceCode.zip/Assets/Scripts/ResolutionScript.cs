﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResolutionScript : MonoBehaviour {

    void Start()
    {
        Screen.SetResolution(900, 900, true);
    }
}
