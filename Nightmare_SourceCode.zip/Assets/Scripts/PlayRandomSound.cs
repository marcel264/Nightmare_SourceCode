﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayRandomSound : MonoBehaviour
{
    public AudioSource audioSource;
    public AudioClip clipOnSource;

    public AudioClip clickSound;
    public AudioClip[] bubbleExplosionClip;

    void Start()
    {
        audioSource = gameObject.GetComponent<AudioSource>();
    }

    public void BubbleExplode()
    {
        int index = Random.Range(0, bubbleExplosionClip.Length);        
        clipOnSource = bubbleExplosionClip[index];
        audioSource.clip = clipOnSource;

        audioSource.Play();        
    }

    public void ButtonClick()
    {
        clipOnSource = clickSound;
        audioSource.clip = clipOnSource;

        audioSource.Play();
    }
}